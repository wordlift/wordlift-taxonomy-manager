<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://wordlift.io
 * @since      1.0.0
 *
 * @package    Wordlift
 * @subpackage Wordlift/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wordlift
 * @subpackage Wordlift/public
 * @author     WordLift <hello@wordlift.io>
 */
class Wordlift_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $plugin_name The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $version The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 *
	 * @param      string $plugin_name The name of the plugin.
	 * @param      string $version     The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wordlift_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wordlift_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wordlift-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wordlift_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wordlift_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		// Prepare a settings array for client-side functions.
		$settings = array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		);

		// If we're in a single page, then print out the post id.
		if ( is_singular() ) {
			$settings['postId'] = get_the_ID();
		}

		// Add flag that we are on home/blog page.
		if ( is_home() || is_front_page() ) {
			$settings['isHome'] = true;
		}

		// By default only enable JSON-LD on supported entity pages (includes
		// `page`, `post` and `entity` by default) and on the home page.
		//
		// @see https://github.com/insideout10/wordlift-plugin/issues/733
		$jsonld_enabled = is_home() || is_front_page() || Wordlift_Entity_Type_Service::is_valid_entity_post_type( get_post_type() );

		// Add the JSON-LD enabled flag, when set to false, the JSON-lD won't
		// be loaded.
		//
		// @see https://github.com/insideout10/wordlift-plugin/issues/642.
		$settings['jsonld_enabled'] = apply_filters( 'wl_jsonld_enabled', $jsonld_enabled );

		// Note that we switched the js to be loaded in footer, since it is loading
		// the json-ld representation.
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wordlift-public.js', array( 'jquery' ), $this->version, true );
		wp_localize_script( $this->plugin_name, 'wlSettings', $settings );

	}

}
