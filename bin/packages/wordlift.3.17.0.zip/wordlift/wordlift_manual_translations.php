<?php

// File created to manage some dynamic translation used in the code
// See http://keithdevon.com/using-variables-wordpress-translation-functions/

__( 'There are no related posts for the current entity.', 'wordlift' );
__( 'This entity has not description.', 'wordlift' );
__( 'There are no related entities for the current entity.', 'wordlift' );
__( 'This entity is not published. It will not appear within analysis results.', 'wordlift' );
__( 'This entity has no featured image yet.', 'wordlift' );
__( 'There are no sameAs configured for this entity.', 'wordlift' );
__( 'Schema.org metadata for this entity are not completed.', 'wordlift' );

