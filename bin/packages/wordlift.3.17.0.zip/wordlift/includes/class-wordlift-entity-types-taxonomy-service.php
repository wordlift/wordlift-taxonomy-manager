<?php

/**
 * The Entity Types Taxonomy service.
 *
 * @since 3.1.0
 */
class Wordlift_Entity_Types_Taxonomy_Service {

	const TAXONOMY_NAME = 'wl_entity_type';

}
